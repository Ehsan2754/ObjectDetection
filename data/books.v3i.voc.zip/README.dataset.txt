# books > 2022-11-26 5:26pm
https://universe.roboflow.com/cv-yovjv/books-umdmd

Provided by a Roboflow user
License: CC BY 4.0

